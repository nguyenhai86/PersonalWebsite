const apiUrl = 'https://mobifonedata.somee.com/api/news';
const mobiNewsIndexDB = 'MobifoneNews';
const tableNameIndexDB = 'news';
let listNews;
// API data
function getAllNews() {
  fetch(apiUrl)
    .then((response) => response.json())
    .then((dataNews) => {
      CreateDB(dataNews);
    })
    .catch((error) => console.error('Error:', error));
}
async function getNewsById(id) {
  try {
    let response = await fetch(apiUrl + '/' + id);
    if (response.ok) {
      let data = await response.json();
      console.log(data);
    } else {
      console.error(`Error fetching news with id ${id}:`, response.status, response.statusText);
    }
  } catch (error) {
    console.error(`Error fetching news with id ${id}:`, error);
  }
}
async function addNews(news) {
  try {
    let response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(news)
    });

    if (response.ok) {
      let result = await response.json();
      console.log('News added successfully:', result);
    } else {
      console.error('Error adding news:', response.status, response.statusText);
    }
  } catch (error) {
    console.error('Error adding news:', error);
  }
}
async function updateNews(news) {
  try {
    let response = await fetch(apiUrl, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(news)
    });

    if (response.ok) {
      let result = await response.json();
      console.log('News updated successfully:', result);
    } else {
      console.error(
        `Error updating news with id ${news.Id}:`,
        response.status,
        response.statusText
      );
    }
  } catch (error) {
    console.error(`Error updating news with id ${news.Id}:`, error);
  }
}

let btnRemove,
  btnDownload,
  btnUpload,
  lblNoficaiton,
  txtName,
  articleid,
  info__tag,
  content_list,
  content_body;
let listPost;
document.addEventListener('DOMContentLoaded', function () {
  btnRemove = document.getElementById('btnRemove');
  btnDownload = document.getElementById('btnDownload');
  btnUpload = document.getElementById('btnUpload');
  lblNoficaiton = document.getElementById('lblNoficaiton');
  txtName = document.getElementById('txtName');
  info__tag = document.getElementById('info__tag');
  txtName.focus();
  articleId = document.getElementById('articleid');
  content_list = document.getElementById('content__list');
  content_body = document.getElementById('content__body');
  btnUpload.addEventListener('click', function () {
    getAllNewsFromIndexDB();
    txtName.focus();
  });
  btnDownload.addEventListener('click', function () {
    getAllNews();
  });
  document.getElementById('txtName').addEventListener('input', function () {
    findNews();
  });
  document.getElementById('txtName').addEventListener('keydown', function (event) {
    if (event.key === 'Enter') {
      getAllNewsFromIndexDB();
      findNews();
    }
  });
});
function CreateDB(dataNews) {
  // Tạo Database
  let deleteRequest = indexedDB.deleteDatabase(mobiNewsIndexDB);
  let request = indexedDB.open(mobiNewsIndexDB, 1);
  request.onupgradeneeded = function (event) {
    let db = event.target.result;
    // Tạo một object store để chứa dữ liệu
    let objectStore = db.createObjectStore(tableNameIndexDB, { keyPath: 'id' });
    objectStore.createIndex('name', 'name', { unique: false });
  };
  request.onsuccess = function (event) {
    let db = event.target.result;
    lblNoficaiton.innerText = 'Database opened successfully';
  };
  request.onerror = function (event) {
    lblNoficaiton.innerText = 'Database error: ' + event.target.errorCode;
  };
  addData(dataNews);
}
function addData(dataNews) {
  let request = indexedDB.open(mobiNewsIndexDB, 1);
  request.onsuccess = function (event) {
    let db = event.target.result;
    let transaction = db.transaction([tableNameIndexDB], 'readwrite');
    let objectStore = transaction.objectStore(tableNameIndexDB);

    dataNews.forEach((item) => {
      let requestAdd = objectStore.add(item);
      requestAdd.onsuccess = function (event) {};
      requestAdd.onerror = function (event) {};
    });
    lblNoficaiton.innerText = 'Data retrieval successful';
  };

  request.onerror = function (event) {
    (lblNoficaiton.innerText = 'Database error: '), event.target.errorCode;
  };
}

function findNews() {
  content_body.innerHTML = ' ';
  content_list.innerHTML = ' ';
  info__tag.innerHTML = ' ';

  let searchTerm = txtName.value;
  const searchTerms = searchTerm
    .toLowerCase()
    .split(',')
    .map((value) => value.trim());

  // Lọc danh sách tin tức dựa trên các từ khóa tìm kiếm
  const filteredNews = listNews.filter((news) =>
    searchTerms.every((term) => news.name.toLowerCase().includes(term))
  );

  // Tạo các phần tử danh sách cho các tin tức đã lọc
  filteredNews.forEach((news) => {
    const itemElement = document.createElement('li');
    itemElement.className = 'list__item';
    itemElement.dataset.id = news.id;
    itemElement.dataset.articleId = news.articleId;
    itemElement.textContent = news.name;
    itemElement.addEventListener('click', () => handleItemClick(news.id));
    content_list.appendChild(itemElement);
  });
}
function handleItemClick(id) {
  var item = listNews.find((i) => i.id === id);
  content_body.innerHTML = ' ';
  content_list.innerHTML = ' ';
  info__tag.innerHTML = ' ';

  content_body.innerHTML = item.content;
}
function getAllNewsFromIndexDB() {
  let request = indexedDB.open(mobiNewsIndexDB, 1);
  request.onsuccess = function (event) {
    let db = event.target.result;
    let transaction = db.transaction([tableNameIndexDB], 'readwrite');
    let objectStore = transaction.objectStore(tableNameIndexDB);
    let request = objectStore.getAll();
    request.onsuccess = function () {
      listNews = request.result;
      console.log(listNews);
    };
  };
}
function validateNumberInput(input) {
  input.value = input.value.replace(/[^0-9]/g, '');
}
