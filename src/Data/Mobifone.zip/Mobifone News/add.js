const apiUrl = 'https://mobifonedata.somee.com/api/news';
// API data
function getAllNews() {
  fetch(apiUrl)
    .then((response) => response.json())
    .then((dataNews) => {})
    .catch((error) => console.error('Error:', error));
}
async function getNewsById(id) {
  try {
    let response = await fetch(apiUrl + '/' + id);
    if (response.ok) {
      let data = await response.json();
      console.log(data);
    } else {
      console.error(`Error fetching news with id ${id}:`, response.status, response.statusText);
    }
  } catch (error) {
    console.error(`Error fetching news with id ${id}:`, error);
  }
}
async function addNews(news) {
  try {
    let response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(news)
    });

    if (response.ok) {
      let result = await response.json();
      lblNofication.innerText = 'News added successfully:' + result;
    } else {
      lblNofication.innerText = 'Error adding news:' + response.statusText;
    }
  } catch (error) {
    lblNofication.innerText = 'Error adding news:' + error;
  }
}
async function updateNews(news) {
  try {
    let response = await fetch(apiUrl, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(news)
    });

    if (response.ok) {
      let result = await response.json();
      console.log('News updated successfully:', result);
    } else {
      console.error(
        `Error updating news with id ${news.Id}:`,
        response.status,
        response.statusText
      );
    }
  } catch (error) {
    console.error(`Error updating news with id ${news.Id}:`, error);
  }
}
let listPost, txtName, txtID, txtTag, txtEditor, btnAdd;

document.addEventListener('DOMContentLoaded', function () {
  txtName = document.getElementById('txtName');
  txtID = document.getElementById('txtID');
  txtTag = document.getElementById('txtTag');
  btnAdd = document.getElementById('btnAdd');
  // Thay thế textarea bằng CKEditor
  CKEDITOR.replace('editor1', {
    height: 300
  });
  btnAdd.addEventListener('click', () => handleBtnAdd());
});
function handleBtnAdd() {
  let nameValue = txtName.value.trim();
  let idValue = txtID.value.trim();
  let tagValue = txtTag.value.trim();
  let contentValue = CKEDITOR.instances.editor1.getData();

  var news = {
    id: 0,
    articleId: idValue,
    name: nameValue,
    tag: tagValue,
    content: contentValue,
    status: true
  };
  addNews(news);
}
function validateNumberInput(input) {
  input.value = input.value.replace(/[^0-9]/g, '');
}
