const apiMF = 'https://apibhs.k-media.vn/api/package/find-detail?packCode=';
const apiSomee = 'https://mobifonedata.somee.com/api/Package/';
let packageName;
let errorString = '';
let popupError;

const fetchData = async () => {
  let apiUrlMF = apiMF + packageName;
  let apiUrlSomee = apiSomee + packageName;
  popupError.textContent = null;
  try {
    const [responseMF, responseSomee] = await Promise.all([fetch(apiUrlMF), fetch(apiUrlSomee)]);

    const dataMF = responseMF.ok ? await responseMF.json().catch(() => null) : null;
    const dataSomee = responseSomee.ok ? await responseSomee.json().catch(() => null) : null;

    if (dataMF || dataSomee) {
      createPopup(dataMF, dataSomee);
    } else {
      popupError.textContent = 'No data found for the package.';
    }
  } catch (error) {
    errorString = error;
    popupError.textContent = errorString;
  }
};
const createPopup = (dataMF, dataSomee) => {
  const popupName = document.getElementById('popup__name');
  const popupAmount = document.getElementById('popup__amount');
  const popupDescription = document.getElementById('popup__description');
  const popupNote = document.getElementById('popup__note');
  const popupUserNote = document.getElementById('popup__usernote');
  const popupLabelMF = document.getElementById('labelMF');
  const popupLabelSomee = document.getElementById('labelSomee');

  popupLabelMF.classList.remove('orange');
  popupLabelSomee.classList.remove('orange');
  popupName.value = packageName;

  if (dataMF) {
    popupAmount.textContent = formatCurrency(dataMF.amount);
    popupDescription.innerHTML = dataMF.description;
    popupNote.innerHTML = dataMF.note;
    popupLabelMF.classList.add('orange');
  } else if (dataSomee) {
    popupAmount.textContent = formatCurrency(dataSomee.amount);
    popupDescription.innerHTML = dataSomee.promotion;
    popupNote.innerHTML = dataSomee.note;
    popupLabelSomee.classList.add('orange');
  }
  if (dataSomee) {
    popupUserNote.textContent = dataSomee.userNote;
  }
};

const formatCurrency = (amount) => {
  return amount.toLocaleString('vi-VN', { style: 'currency', currency: 'VND' });
};
document.addEventListener('DOMContentLoaded', function () {
  document.getElementById('popup__name').focus();
  popupError = document.getElementById('errorstring');
});
// fetchData();
document.addEventListener('DOMContentLoaded', function () {
  var inputElement = document.getElementById('popup__name');

  inputElement.addEventListener('keydown', function (event) {
    if (event.keyCode === 13) {
      handle();
    }
  });
  inputElement.addEventListener('blur', handle);
  function handle() {
    packageName = inputElement.value;
    packageName = packageName.toUpperCase().trim();
    fetchData();
  }
});
