const apiMF = 'https://apibhs.k-media.vn/api/package/find-detail?packCode=';
const apiSomee = 'https://mobifonedata.somee.com/api/Package/';
let packageName;
let popupError;
let popupEditCheckbox;
let popupName, buttonAdd, buttonUpdate, buttonRemove;
let dataMF, dataSomee;

const fetchData = async () => {
  const apiUrlMF = `${apiMF}${packageName}`;
  const apiUrlSomee = `${apiSomee}${packageName}`;
  popupError.textContent = '';

  try {
    const [responseMF, responseSomee] = await Promise.all([fetch(apiUrlMF), fetch(apiUrlSomee)]);

    dataMF = responseMF.ok ? await responseMF.json().catch(() => null) : null;
    dataSomee = responseSomee.ok ? await responseSomee.json().catch(() => null) : null;

    if (dataMF || dataSomee) {
      createView();
    } else {
      popupError.textContent = 'No data found for the package.';
    }
  } catch (error) {
    popupError.textContent = `Error: ${error.message}`;
  }
};

const createView = () => {
  const popupAmount = document.getElementById('popup__amount');
  const popupDescription = document.getElementById('popup__description');
  const popupNote = document.getElementById('popup__note');
  const popupUserNote = document.getElementById('popup__usernote');
  const popupLabelMF = document.getElementById('labelMF');
  const popupLabelSomee = document.getElementById('labelSomee');

  [popupLabelMF, popupLabelSomee].forEach((label) => label.classList.remove('orange'));
  popupName.value = packageName;

  if (dataMF) {
    popupAmount.textContent = formatCurrency(dataMF.amount);
    popupDescription.innerHTML = dataMF.description;
    popupNote.innerHTML = dataMF.note;
    popupUserNote.innerHTML = null;
    popupLabelMF.classList.add('orange');
  } else if (dataSomee) {
    popupAmount.textContent = formatCurrency(dataSomee.amount);
    popupDescription.innerHTML = dataSomee.promotion;
    popupNote.innerHTML = dataSomee.note;
    popupUserNote.innerHTML = null;
  }
  if (dataSomee) {
    popupUserNote.textContent = dataSomee.userNote;
    popupLabelSomee.classList.add('orange');
  }
};
const convertToEdit = () => {
  const elementsToConvert = [
    'popup__amount',
    'popup__description',
    'popup__note',
    'popup__usernote'
  ];

  elementsToConvert.forEach((id) => {
    const divElement = document.getElementById(id);
    let inputElement;
    if (id === 'popup__amount') {
      inputElement = document.createElement('input');
    } else inputElement = document.createElement('textarea');
    inputElement.id = id;
    inputElement.name = id;
    if (id === 'popup__amount') {
      inputElement.value = divElement.innerText;
    } else inputElement.value = divElement.innerHTML;
    inputElement.spellcheck = 'false';
    divElement.parentNode.replaceChild(inputElement, divElement);
  });
};

async function postPackage(packageData) {
  try {
    const response = await fetch(apiSomee, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(packageData)
    });

    if (!response.ok) {
      popupError.textContent = 'Error: ' + response.status;
    }
    const result = await response.json();
    popupError.textContent = 'Package post successfully:' + result;
  } catch (error) {
    popupError.textContent = 'Error post package:' + error;
  }
}
async function putPackage(packageData) {
  const url = apiSomee;
  try {
    const response = await fetch(url, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(packageData)
    });

    if (!response.ok) {
      popupError.textContent = 'Error: ' + response.status;
    }
    const result = await response.json();
    popupError.textContent = 'Package update successfully:' + result;
  } catch (error) {
    popupError.textContent = 'Error update package:' + error;
  }
}
async function deletePackage(packageData) {
  let packageName = packageData.name;
  const url = apiSomee + packageName;

  try {
    const response = await fetch(url, {
      method: 'DELETE'
    });

    if (!response.ok) {
      popupError.textContent = 'Error: ' + response.status;
    }
    const result = await response.json();
    popupError.textContent = 'Package delete successfully:' + result;
  } catch (error) {
    popupError.textContent = 'Error delete package:' + error;
  }
}
document.addEventListener('DOMContentLoaded', () => {
  popupError = document.getElementById('errorstring');
  popupEditCheckbox = document.getElementById('checkboxEdit');
  buttonAdd = document.getElementById('btnAdd');
  buttonUpdate = document.getElementById('btnUpdate');
  buttonRemove = document.getElementById('btnRemove');

  buttonAdd.style.visibility = 'hidden';
  buttonUpdate.style.visibility = 'hidden';
  buttonRemove.style.visibility = 'hidden';

  const inputElement = document.getElementById('popup__name');
  inputElement.focus();

  inputElement.addEventListener('keydown', (event) => {
    if (event.keyCode === 13) {
      handleFetch();
    }
  });
  popupEditCheckbox.addEventListener('change', (event) => {
    if (event.currentTarget.checked) {
      convertToEdit();
      buttonAdd.style.visibility = 'visible';
      buttonUpdate.style.visibility = 'visible';
      buttonRemove.style.visibility = 'visible';
    } else {
      document.cookie = packageName;
      window.location.reload(true);
    }
  });

  inputElement.addEventListener('blur', handleFetch);

  function handleFetch() {
    packageName = inputElement.value.trim().toUpperCase();
    if (packageName) {
      fetchData();
    }
  }
});
document.addEventListener('DOMContentLoaded', () => {
  // Lấy tham chiếu đến nút btnAdd
  const buttonAdd = document.getElementById('btnAdd');
  const buttonUpdate = document.getElementById('btnUpdate');
  const buttonRemove = document.getElementById('btnRemove');
  popupName = document.getElementById('popup__name');
  packageName = document.cookie;
  document.cookie = 'null';
  console.log(packageName);
  if (packageName != 'null') {
    popupName.value = packageName;
    document.cookie = 'null';
    fetchData();
  }
  // Thêm sự kiện click listener vào nút btnAdd
  buttonAdd.addEventListener('click', async () => {
    try {
      // Tạo package từ các giá trị nhập vào
      const packageData = createPackage();

      // Gọi hàm postPackage với packageData
      await postPackage(packageData);
    } catch (error) {
      popupError.textContent = 'Error adding package: ' + error.message;
    }
  });
  buttonUpdate.addEventListener('click', async () => {
    try {
      // Tạo package từ các giá trị nhập vào
      const packageData = createPackage();

      await putPackage(packageData);
    } catch (error) {
      popupError.textContent = 'Error adding package: ' + error.message;
    }
  });
  buttonRemove.addEventListener('click', async () => {
    try {
      // Tạo package từ các giá trị nhập vào
      const packageData = createPackage();
      await deletePackage(packageData);
    } catch (error) {
      popupError.textContent = 'Error adding package: ' + error.message;
    }
  });
});
const formatCurrency = (amount) =>
  amount.toLocaleString('vi-VN', { style: 'currency', currency: 'VND' });
function convertCurrencyStringToNumber(currencyString) {
  // Loại bỏ khoảng trắng và ký tự ₫
  let cleanedString = currencyString.replace(/[.đ\s]/g, '');

  // Chuyển đổi chuỗi sang số
  let numberValue = parseFloat(cleanedString);

  return numberValue;
}
function createPackage() {
  let package;
  var name = document.getElementById('popup__name').value;
  var amount = convertCurrencyStringToNumber(document.getElementById('popup__amount').value);
  var promotion = document.getElementById('popup__description').value;
  var note = document.getElementById('popup__note').value;
  var userNote = document.getElementById('popup__usernote').value;

  package = {
    name: name,
    amount: amount,
    promotion: promotion,
    note: note,
    userNote: userNote
  };
  return package;
}
